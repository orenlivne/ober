Ober resources data retrieval scripts (in particular, Hutterites resources).

See also Jessica Chong's Github site https://raw.github.com/jxchong
