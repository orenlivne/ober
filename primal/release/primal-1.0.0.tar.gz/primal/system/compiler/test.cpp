#include <cstdio>
int main() {
    printf("sizeof(void*)=%d bytes\n", sizeof(void*));
    return 0;
}