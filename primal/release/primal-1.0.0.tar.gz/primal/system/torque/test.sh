#!/bin/sh

echo $HOSTNAME
