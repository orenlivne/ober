#!/bin/bash

echo "Job array: ${PBS_ARRAYID}, ${PBS_JOBNAME}"
echo "${VAR1}, ${VAR2}"
