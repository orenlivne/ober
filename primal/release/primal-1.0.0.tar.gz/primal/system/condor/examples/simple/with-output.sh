#!/bin/bash
mkdir -p out
cp a.txt out/b.txt
uname -a
pwd
ls -lR
