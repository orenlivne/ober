Ober Subversion Repository
==========================
So far mostly contain code written by Oren Livne, but more people may add their code soon.

* code - phasing and imputation project code - Python 2.7

* doc - phasing and imputation project documentation:
  - Presentations
  - Analyzed test cases and plots
  - Lawrence's old phasing and imputation Perl code (2011)

* system - general-purpose bash scripts, system tools, software configuration
  - bash_profile for various machines
  - ipython configuration

* testdata - phasing and imputation project test data
  - PLINK format
  - NPZ format (binary Python)
