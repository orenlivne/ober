'''
============================================================
Pre-processing scripts package (converting from other
formats to NPZ; preparing SNP annotation database; etc.)

Created on October 31, 2012
@author: Oren Livne <livne@uchicago.edu>
============================================================
'''
import convert
