'''
============================================================
Plotting modules.

Created on May 30, 2012
@author: Oren Livne <livne@uchicago.edu>
============================================================
'''
import colors
try:
    import plots
except ImportError, e:
    # matplotlib not installed
    pass
