'''
============================================================
Main math utilities package.

Created on December 4, 2012
@author: Oren Livne <livne@uchicago.edu>
============================================================
'''
from index_util import *
