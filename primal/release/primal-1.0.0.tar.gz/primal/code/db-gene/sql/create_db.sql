mysql -u impute -pimpute impute < ~/ober/impute/db/impute.sql
